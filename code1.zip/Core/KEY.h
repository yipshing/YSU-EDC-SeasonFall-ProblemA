#include "main.h"
#include "GUI.h"

void keyscan(void);
void key_handle(void);
void sw_handle(void);
